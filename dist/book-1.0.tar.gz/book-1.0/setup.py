from distutils.core import setup, Extension

setup(name='book',version='1.0',classifiers = ['SubwayInfoApp'],packages=['SubwayInfoApp'],)